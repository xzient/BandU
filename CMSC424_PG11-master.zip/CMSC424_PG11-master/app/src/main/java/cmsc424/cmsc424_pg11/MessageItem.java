package cmsc424.cmsc424_pg11;

public class MessageItem {

    String titleM, messageM, genreM;



    public MessageItem() {

    }
}
